-- EstoqMais 1.0: execute no SQL Editor do SEU projeto Supabase.
-- Não inclui senha nem chave secreta. Reexecutar não apaga registros.
begin;
create table if not exists public.estoqmais_state (
 user_id uuid primary key references auth.users(id) on delete cascade,
 data jsonb not null,
 version bigint not null check (version > 0),
 saved_at timestamptz not null default now()
);
create table if not exists public.estoqmais_backups (
 user_id uuid not null references auth.users(id) on delete cascade,
 version bigint not null,
 data jsonb not null,
 saved_at timestamptz not null default now(),
 primary key(user_id,version)
);
alter table public.estoqmais_state enable row level security;
alter table public.estoqmais_backups enable row level security;
drop policy if exists estoqmais_read_own_state on public.estoqmais_state;
create policy estoqmais_read_own_state on public.estoqmais_state for select to authenticated using ((select auth.uid())=user_id);
drop policy if exists estoqmais_read_own_backups on public.estoqmais_backups;
create policy estoqmais_read_own_backups on public.estoqmais_backups for select to authenticated using ((select auth.uid())=user_id);
revoke all on public.estoqmais_state,public.estoqmais_backups from anon,authenticated;
grant select on public.estoqmais_state,public.estoqmais_backups to authenticated;
-- Gravação somente via função: proprietário conferido no servidor, revisão
-- comparada e histórico criado na MESMA transação. Nenhum cliente escolhe o UID.
create or replace function public.estoqmais_save(p_data jsonb,p_expected bigint,p_operation uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
 v_uid uuid:=auth.uid(); v_current bigint; v_saved timestamptz; v_old jsonb;
begin
 if v_uid is null then raise exception 'authentication_required' using errcode='42501'; end if;
 if p_expected is null or p_expected<0 or p_operation is null then raise exception 'invalid_request'; end if;
 if jsonb_typeof(p_data) is distinct from 'object'
 or jsonb_typeof(p_data->'products') is distinct from 'array'
 or jsonb_typeof(p_data->'suppliers') is distinct from 'array'
 or jsonb_typeof(p_data->'purchases') is distinct from 'array'
 or jsonb_typeof(p_data->'moves') is distinct from 'array'
 or octet_length(p_data::text)>5242880 then raise exception 'invalid_data'; end if;
 perform pg_advisory_xact_lock(hashtextextended(v_uid::text,0));
 select version,saved_at,data into v_current,v_saved,v_old from public.estoqmais_state where user_id=v_uid;
 v_current:=coalesce(v_current,0);
 -- Idempotência permite repetir uma gravação cuja resposta de rede foi perdida.
 if v_current=p_expected+1 and v_old->>'_cloudOperation'=p_operation::text then
  return jsonb_build_object('ok',true,'version',v_current,'saved_at',v_saved);
 end if;
 if v_current<>p_expected then return jsonb_build_object('ok',false,'conflict',true,'version',v_current); end if;
 v_saved:=clock_timestamp();
 p_data:=p_data||jsonb_build_object('_cloudOperation',p_operation::text);
 insert into public.estoqmais_state(user_id,data,version,saved_at) values(v_uid,p_data,v_current+1,v_saved)
 on conflict(user_id) do update set data=excluded.data,version=excluded.version,saved_at=excluded.saved_at;
 insert into public.estoqmais_backups(user_id,data,version,saved_at) values(v_uid,p_data,v_current+1,v_saved);
 delete from public.estoqmais_backups where user_id=v_uid and version<=v_current+1-10;
 return jsonb_build_object('ok',true,'version',v_current+1,'saved_at',v_saved);
end $$;
revoke all on function public.estoqmais_save(jsonb,bigint,uuid) from public,anon;
grant execute on function public.estoqmais_save(jsonb,bigint,uuid) to authenticated;
commit;
