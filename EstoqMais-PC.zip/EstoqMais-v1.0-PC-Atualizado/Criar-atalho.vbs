Option Explicit
Dim fso, shell, folder, target, icon, desktopPath, shortcut
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
target = fso.BuildPath(folder, "EstoqMais.html")
icon = fso.BuildPath(folder, "EstoqMais.ico")
If Not fso.FileExists(target) Or Not fso.FileExists(icon) Then
  MsgBox "Extraia todos os arquivos do ZIP para a mesma pasta antes de criar o atalho.", 48, "EstoqMais"
  WScript.Quit 1
End If
desktopPath = shell.SpecialFolders("Desktop")
On Error Resume Next
Set shortcut = shell.CreateShortcut(fso.BuildPath(desktopPath, "EstoqMais.lnk"))
shortcut.TargetPath = target
shortcut.WorkingDirectory = folder
shortcut.IconLocation = icon & ",0"
shortcut.Description = "EstoqMais - Controle de Compras"
shortcut.WindowStyle = 1
shortcut.Save
If Err.Number <> 0 Then
  MsgBox "Nao foi possivel criar o atalho: " & Err.Description, 48, "EstoqMais"
  WScript.Quit 1
End If
On Error GoTo 0
MsgBox "Atalho EstoqMais criado na Area de Trabalho com a logo do sistema. Mantenha esta pasta no mesmo local.", 64, "EstoqMais"
